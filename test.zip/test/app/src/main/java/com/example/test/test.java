package com.example.test;

public interface test {
}
