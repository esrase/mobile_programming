package com.example.test;

public class SoruCevap {
    public static String[] question ={
            "Who was the first person to jump over the gap in the stairs in Khazad-dûm?",
            "Complete the blank: 'I'm wasted on cross country, we dwarves are ____________.'",
            "What was the name of Théodred's horse?",
            "The name of Gandalf's horse was _________.",
            "Why did Saruman tell the orcs to burn Fangorn Forest?",
            "How do Sam and Frodo escape the inspection when they are hiding among the orcs in Mordor?"
    };
    public static String[][] answer ={
            {"Legolas","Gandalf","Frodo","Boromir"},
            {"real filth","natural sprinters","meant for marathons","cannibals"},
            {"Brego","Hasufel","Arod","Prego"},
            {"Shadowfax","Mr.oats","Lil'Jimbo","Nightrider"},
            {"It smelled weird","They need fuel for the fires","They need sticks to make the swords","It was in the way"},
            {"They caused a fight so they could escape","Gollum saved them","They beat up the inspector orc","They offered the orcs Lembas bread"}
    };
    public static String[] trueAnswer ={
            "Legolas",
            "natural sprinters",
            "Brego",
            "Shadowfax",
            "They need fuel for the fires",
            "They caused a fight so they could escape"
    };
}
